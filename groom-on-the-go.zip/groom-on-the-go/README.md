# Groom on the Go

A Pen created on CodePen.

Original URL: [https://codepen.io/vygpmfqs-the-selector/pen/dPNNxKM](https://codepen.io/vygpmfqs-the-selector/pen/dPNNxKM).

